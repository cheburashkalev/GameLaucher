#pragma once
#include <Game/Tray/include/components/button.hpp>
#include <Game/Tray/include/components/imagebutton.hpp>
#include <Game/Tray/include/components/label.hpp>
#include <Game/Tray/include/components/separator.hpp>
#include <Game/Tray/include/components/submenu.hpp>
#include <Game/Tray/include/components/syncedtoggle.hpp>
#include <Game/Tray/include/components/toggle.hpp>

#if PLATFORM_WINDOWS	
#include <Game/Tray/include/core/windows/tray.hpp>
#elif PLATFORM_LINUX
#include <Game/Tray/include/core/linux/tray.hpp>
#endif