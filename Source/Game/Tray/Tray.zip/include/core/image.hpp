#pragma once
#include <string>
#if PLATFORM_WINDOWS
#include "icon.hpp"
#include <Windows.h>
#elif PLATFORM_LINUX
#include <gtk/gtk.h>
#endif

namespace Tray
{
#if PLATFORM_LINUX
    class Image
    {
        GtkWidget *image;

      public:
        Image(GtkWidget *image);
        Image(const char *path);
        Image(const std::string &path);

        operator GtkWidget *();
    };
#elif PLATFORM_WINDOWS
    class Image
    {
        HBITMAP image;

      public:
        Image(HBITMAP image);
        Image(WORD resource);
        Image(const char *path);
        Image(const std::string &path);

        operator HBITMAP();
    };
#endif
} // namespace Tray