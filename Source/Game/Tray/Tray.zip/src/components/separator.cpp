#include <Game/Tray/include/components/separator.hpp>
#include <Game/Tray/include/core/entry.hpp>

Tray::Separator::Separator() : TrayEntry("") {}