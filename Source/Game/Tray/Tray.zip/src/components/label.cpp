#include <Game/Tray/include/components/label.hpp>

Tray::Label::Label(std::string text) : TrayEntry(std::move(text)) {}